var UnoAppManifest = {
    displayName: "UnoApp3",
    splashScreenImage: "splash_screen.scale-200.png",
    splashScreenColor: "#ffffff",
}